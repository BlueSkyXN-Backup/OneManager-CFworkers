# OneManager-cfworkerskv
部署教程：https://www.blueskyxn.com/202102/3903.html


只有主要功能可用，可以添加盘，可以刷新缓存。  
不可用：加密目录、管理操作、上传。  
